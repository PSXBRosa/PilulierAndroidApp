package com.example.app_mob_2;

public class EditAdapter {
}
